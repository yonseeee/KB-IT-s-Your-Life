package ch15.sec05.exam01;

public class TreeSetExample {
    public static void main(String[] args) {

    }
}
