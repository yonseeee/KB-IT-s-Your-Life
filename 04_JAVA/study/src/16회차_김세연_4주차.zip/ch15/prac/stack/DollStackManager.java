package ch15.prac.stack;

import java.util.Stack;

public class DollStackManager {
    Stack<String> stack;
    private static final String[] dolls={
            "피카츄", "리자몽", "꼬부기", "쿠로미", "헬로키티",
            "뽀로로", "짱구", "도라에몽", "스폰지밥", "미니언"
    };

    public String storeRandomDoll(){
        int index=(int)(Math.random()*dolls.length);
        return dolls[index];
    }
    public void showStack(){

    }
}
