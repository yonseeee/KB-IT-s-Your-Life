package org.scoula.security.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

//보안 필터 등록하는 클래스 상속
//상속만 받으면 자동으로 됨
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {//security filter의 연결 순서 조정

}
